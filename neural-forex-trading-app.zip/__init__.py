"""
Neural Forex Trading App
=======================

Professional neural network-powered forex trading application.
"""

__version__ = "1.0.0"
__author__ = "Neural Trading System"
