#!/usr/bin/env python3
"""
Neural Model Manager
===================

Professional neural model manager for the trading app.
Handles model loading, validation, training, and management.

Features:
- Automatic model loading from saved files
- Model validation and testing
- Model training capabilities
- Version management
- Performance metrics tracking
- Model backup and restore
"""

import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import pickle
import logging
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
import threading

class SimpleNeuralNetwork(nn.Module):
    """Simple neural network for forex prediction"""
    
    def __init__(self, input_dim: int):
        super(SimpleNeuralNetwork, self).__init__()
        
        self.network = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 3)  # SELL, HOLD, BUY
        )
    
    def forward(self, x):
        return self.network(x)

class NeuralModelManager:
    """Professional neural model manager"""
    
    def __init__(self, models_dir: str = "models"):
        self.logger = logging.getLogger(__name__)
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(exist_ok=True)
        
        # Model state
        self.current_model = None
        self.model_metadata = {}
        self.model_loaded = False
        
        # Training data cache
        self.training_data = None
        self.feature_dim = 6  # Default feature dimension
        
        # Performance tracking
        self.performance_history = []
        
        # Thread safety
        self._lock = threading.Lock()
    
    def load_model(self, model_path: str = None) -> bool:
        """
        Load neural model from file
        
        Args:
            model_path: Path to model file (uses default if None)
            
        Returns:
            bool: True if model loaded successfully
        """
        with self._lock:
            try:
                if model_path is None:
                    # Look for default model file
                    default_paths = [
                        "neural_model.pth",
                        "models/best_model.pth",
                        "models/current_model.pth"
                    ]
                    
                    model_path = None
                    for path in default_paths:
                        if Path(path).exists():
                            model_path = path
                            break
                    
                    if model_path is None:
                        self.logger.error("No model file found")
                        return False
                
                self.logger.info(f"Loading neural model from {model_path}")
                
                # Load checkpoint
                checkpoint = torch.load(model_path, map_location='cpu')
                
                # Create model instance
                self.current_model = SimpleNeuralNetwork(input_dim=self.feature_dim)
                
                # Load weights
                if 'model_state_dict' in checkpoint:
                    self.current_model.load_state_dict(checkpoint['model_state_dict'])
                else:
                    self.current_model.load_state_dict(checkpoint)
                
                self.current_model.eval()
                
                # Load metadata
                if 'metadata' in checkpoint:
                    self.model_metadata = checkpoint['metadata']
                elif 'training_date' in checkpoint:
                    self.model_metadata = {
                        'training_date': checkpoint['training_date'],
                        'accuracy': checkpoint.get('accuracy', 'Unknown'),
                        'win_rate': checkpoint.get('win_rate', 'Unknown')
                    }
                else:
                    self.model_metadata = {
                        'training_date': 'Unknown',
                        'accuracy': 'Unknown',
                        'win_rate': 'Unknown'
                    }
                
                self.model_loaded = True
                
                self.logger.info("Neural model loaded successfully")
                self.logger.info(f"Model metadata: {self.model_metadata}")
                
                return True
                
            except Exception as e:
                self.logger.error(f"Error loading model: {e}")
                self.current_model = None
                self.model_loaded = False
                return False
    
    def save_model(self, model_path: str, metadata: Dict[str, Any] = None) -> bool:
        """
        Save current model to file
        
        Args:
            model_path: Path to save model
            metadata: Optional model metadata
            
        Returns:
            bool: True if saved successfully
        """
        with self._lock:
            try:
                if not self.model_loaded or self.current_model is None:
                    self.logger.error("No model loaded to save")
                    return False
                
                # Prepare save data
                save_data = {
                    'model_state_dict': self.current_model.state_dict(),
                    'feature_dim': self.feature_dim,
                    'metadata': metadata or self.model_metadata,
                    'save_date': datetime.now().isoformat()
                }
                
                # Ensure directory exists
                Path(model_path).parent.mkdir(parents=True, exist_ok=True)
                
                # Save model
                torch.save(save_data, model_path)
                
                self.logger.info(f"Model saved to {model_path}")
                return True
                
            except Exception as e:
                self.logger.error(f"Error saving model: {e}")
                return False
    
    def is_model_loaded(self) -> bool:
        """Check if model is loaded"""
        return self.model_loaded and self.current_model is not None
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about current model
        
        Returns:
            Dict containing model information
        """
        if not self.is_model_loaded():
            return {"error": "No model loaded"}
        
        # Count parameters
        total_params = sum(p.numel() for p in self.current_model.parameters())
        trainable_params = sum(p.numel() for p in self.current_model.parameters() if p.requires_grad)
        
        info = {
            "model_loaded": True,
            "feature_dimension": self.feature_dim,
            "total_parameters": total_params,
            "trainable_parameters": trainable_params,
            "model_size_mb": self._estimate_model_size(),
            "metadata": self.model_metadata,
            "performance_history": self.performance_history[-10:] if self.performance_history else []
        }
        
        return info
    
    def _estimate_model_size(self) -> float:
        """Estimate model size in MB"""
        if not self.is_model_loaded():
            return 0.0
        
        param_size = 0
        for param in self.current_model.parameters():
            param_size += param.numel() * param.element_size()
        
        buffer_size = 0
        for buffer in self.current_model.buffers():
            buffer_size += buffer.numel() * buffer.element_size()
        
        total_size = param_size + buffer_size
        return total_size / (1024 * 1024)  # Convert to MB
    
    def predict(self, features: np.ndarray) -> Optional[Dict[str, Any]]:
        """
        Make prediction using loaded model
        
        Args:
            features: Input features array
            
        Returns:
            Dict containing prediction results or None
        """
        if not self.is_model_loaded():
            self.logger.error("No model loaded for prediction")
            return None
        
        try:
            with torch.no_grad():
                # Ensure features are correct shape
                if features.ndim == 1:
                    features = features.reshape(1, -1)
                
                # Convert to tensor
                X = torch.FloatTensor(features)
                
                # Make prediction
                outputs = self.current_model(X)
                
                # Get probabilities
                probabilities = torch.softmax(outputs, dim=1).numpy()[0]
                predicted_class = torch.argmax(outputs, dim=1).item()
                
                # Map classes
                classes = ['SELL', 'HOLD', 'BUY']
                predicted_action = classes[predicted_class]
                confidence = probabilities[predicted_class]
                
                return {
                    'action': predicted_action,
                    'confidence': confidence,
                    'probabilities': {
                        'SELL': float(probabilities[0]),
                        'HOLD': float(probabilities[1]),
                        'BUY': float(probabilities[2])
                    },
                    'raw_outputs': outputs.numpy().tolist()
                }
                
        except Exception as e:
            self.logger.error(f"Prediction error: {e}")
            return None
    
    def validate_model(self, test_features: np.ndarray, test_labels: np.ndarray) -> Dict[str, Any]:
        """
        Validate model performance on test data
        
        Args:
            test_features: Test feature array
            test_labels: True labels array
            
        Returns:
            Dict containing validation metrics
        """
        if not self.is_model_loaded():
            return {"error": "No model loaded for validation"}
        
        try:
            predictions = []
            confidences = []
            
            # Make predictions on test data
            for i in range(len(test_features)):
                pred = self.predict(test_features[i])
                if pred:
                    predictions.append(pred['action'])
                    confidences.append(pred['confidence'])
            
            if not predictions:
                return {"error": "No valid predictions made"}
            
            # Calculate metrics
            accuracy = self._calculate_accuracy(predictions, test_labels)
            avg_confidence = np.mean(confidences)
            
            # Store performance
            performance = {
                'validation_date': datetime.now().isoformat(),
                'accuracy': accuracy,
                'average_confidence': avg_confidence,
                'num_predictions': len(predictions)
            }
            
            self.performance_history.append(performance)
            
            self.logger.info(f"Model validation completed - Accuracy: {accuracy:.3f}, Confidence: {avg_confidence:.3f}")
            
            return performance
            
        except Exception as e:
            self.logger.error(f"Model validation error: {e}")
            return {"error": str(e)}
    
    def _calculate_accuracy(self, predictions: List[str], true_labels: np.ndarray) -> float:
        """Calculate prediction accuracy"""
        if len(predictions) != len(true_labels):
            return 0.0
        
        # Convert string predictions to numeric
        pred_map = {'SELL': 0, 'HOLD': 1, 'BUY': 2}
        numeric_predictions = [pred_map.get(pred, 1) for pred in predictions]
        
        correct = sum(1 for p, t in zip(numeric_predictions, true_labels) if p == t)
        accuracy = correct / len(predictions)
        
        return accuracy
    
    def train_new_model(self, training_data: Tuple[np.ndarray, np.ndarray], 
                       epochs: int = 100, learning_rate: float = 0.001) -> bool:
        """
        Train a new neural model
        
        Args:
            training_data: Tuple of (features, labels)
            epochs: Number of training epochs
            learning_rate: Learning rate for optimizer
            
        Returns:
            bool: True if training successful
        """
        try:
            features, labels = training_data
            
            # Update feature dimension
            self.feature_dim = features.shape[1] if len(features.shape) > 1 else 1
            
            # Create new model
            self.current_model = SimpleNeuralNetwork(input_dim=self.feature_dim)
            optimizer = torch.optim.Adam(self.current_model.parameters(), lr=learning_rate)
            criterion = nn.CrossEntropyLoss()
            
            # Convert to tensors
            X = torch.FloatTensor(features)
            y = torch.LongTensor(labels)
            
            # Training loop
            self.current_model.train()
            for epoch in range(epochs):
                optimizer.zero_grad()
                outputs = self.current_model(X)
                loss = criterion(outputs, y)
                loss.backward()
                optimizer.step()
                
                if epoch % 20 == 0:
                    self.logger.info(f"Training epoch {epoch}/{epochs}, Loss: {loss.item():.4f}")
            
            # Evaluate on training data
            self.current_model.eval()
            with torch.no_grad():
                outputs = self.current_model(X)
                predictions = torch.argmax(outputs, dim=1)
                accuracy = (predictions == y).float().mean().item()
            
            # Update metadata
            self.model_metadata = {
                'training_date': datetime.now().isoformat(),
                'training_epochs': epochs,
                'learning_rate': learning_rate,
                'training_accuracy': accuracy,
                'feature_dimension': self.feature_dim,
                'training_samples': len(features)
            }
            
            self.model_loaded = True
            
            self.logger.info(f"Model training completed - Final accuracy: {accuracy:.3f}")
            return True
            
        except Exception as e:
            self.logger.error(f"Model training error: {e}")
            return False
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """
        Get list of available model files
        
        Returns:
            List of model information dictionaries
        """
        models = []
        
        # Look for .pth files in models directory
        for model_file in self.models_dir.glob("*.pth"):
            try:
                # Get file stats
                stat = model_file.stat()
                
                # Try to load metadata
                metadata = {}
                try:
                    checkpoint = torch.load(model_file, map_location='cpu')
                    if 'metadata' in checkpoint:
                        metadata = checkpoint['metadata']
                    elif 'training_date' in checkpoint:
                        metadata = {'training_date': checkpoint['training_date']}
                except:
                    pass
                
                models.append({
                    'file_path': str(model_file),
                    'file_name': model_file.name,
                    'file_size_mb': stat.st_size / (1024 * 1024),
                    'created_date': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                    'modified_date': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    'metadata': metadata
                })
                
            except Exception as e:
                self.logger.error(f"Error reading model {model_file}: {e}")
        
        # Sort by modification date (newest first)
        models.sort(key=lambda x: x['modified_date'], reverse=True)
        
        return models
    
    def delete_model(self, model_path: str) -> bool:
        """
        Delete a model file
        
        Args:
            model_path: Path to model file
            
        Returns:
            bool: True if deleted successfully
        """
        try:
            model_file = Path(model_path)
            if model_file.exists():
                model_file.unlink()
                self.logger.info(f"Deleted model: {model_path}")
                return True
            else:
                self.logger.warning(f"Model file not found: {model_path}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error deleting model {model_path}: {e}")
            return False
    
    def backup_model(self, backup_name: str = None) -> str:
        """
        Create backup of current model
        
        Args:
            backup_name: Optional backup name
            
        Returns:
            str: Path to backup file
        """
        if not self.is_model_loaded():
            self.logger.error("No model loaded to backup")
            return ""
        
        try:
            if backup_name is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_name = f"backup_{timestamp}.pth"
            
            backup_path = self.models_dir / backup_name
            
            # Save current model as backup
            backup_metadata = {
                **self.model_metadata,
                'backup_date': datetime.now().isoformat(),
                'backup_type': 'manual'
            }
            
            if self.save_model(str(backup_path), backup_metadata):
                self.logger.info(f"Model backed up to: {backup_path}")
                return str(backup_path)
            else:
                return ""
                
        except Exception as e:
            self.logger.error(f"Model backup error: {e}")
            return ""
